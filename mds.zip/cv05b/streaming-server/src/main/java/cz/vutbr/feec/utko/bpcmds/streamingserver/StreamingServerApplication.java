package cz.vutbr.feec.utko.bpcmds.streamingserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamingServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamingServerApplication.class, args);
	}

}
