package cz.vutbr.feec.utko.bpcmds.streamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
