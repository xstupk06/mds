package cz.vutbr.feec.utko.bpcmds.du4;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CopyOnWriteArrayList;

@Controller
public class WebController {

    private CopyOnWriteArrayList<Video> avengerList = new CopyOnWriteArrayList<>();

    @RequestMapping(value="/videolibrary", method = {RequestMethod.POST, RequestMethod.GET})
    public String goHome(Model model){
        model.addAttribute("videoList", avengerList);
        return "index";
    }

    @GetMapping("/addVideo")
    public String goToAdd(Model model){
        model.addAttribute("video", new Video());
        return "add_avenger";
    }

    @PostMapping("/addAvenger")
    public String addAvenger(@ModelAttribute Video video){
        avengerList.add(video);
        return "redirect:/videolibrary";
    }
















    @GetMapping("/bob")
    public String bob(){
        return "bob";
    }

}
