package cz.vutbr.feec.utko.bpcmds.du4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Du4Application {

	public static void main(String[] args) {
		SpringApplication.run(Du4Application.class, args);
	}

}
