package cz.vutbr.feec.utko.bpcmds.du4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Du4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
