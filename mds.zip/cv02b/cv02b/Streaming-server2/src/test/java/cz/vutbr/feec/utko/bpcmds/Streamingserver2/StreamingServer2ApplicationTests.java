package cz.vutbr.feec.utko.bpcmds.Streamingserver2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingServer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
