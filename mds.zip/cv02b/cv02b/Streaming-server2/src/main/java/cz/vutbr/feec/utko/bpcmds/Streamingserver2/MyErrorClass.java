package cz.vutbr.feec.utko.bpcmds.Streamingserver2;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/*
    Bonus: řešeno ve čtvrtečních cvičení
    Třída navíc, která řeší zobrazení vlastní error zprávy v případě, že daná adresa neexistuje.

 */
@Controller
public class MyErrorClass implements ErrorController {

    @GetMapping("/error")
    public String handleError(){
        return "error";
    }
}
